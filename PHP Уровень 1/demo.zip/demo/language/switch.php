<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
	<title>switch</title>
</head>

<body>
<h1>switch</h1>
<?php
	$a = 2;

	switch ($a){
		case 1: 
			echo "����";
		case 2: 
			echo "���";
		case 3: 
			echo "���";
		case 4: 
			echo "������";
	}
?>

</body>
</html>
