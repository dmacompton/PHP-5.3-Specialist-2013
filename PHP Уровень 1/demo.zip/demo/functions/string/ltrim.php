<HTML>
<HEAD>
<TITLE>ltrim</TITLE>
</HEAD>
<BODY>
<?
	$text = "     Leading whitespace";
	print("<PRE>" . ltrim($text) . "</PRE>");
?>
</BODY>
</HTML>