<HTML>
<HEAD>
<TITLE>str_repeat</TITLE>
</HEAD>
<BODY>
<?
	print(str_repeat("PHP!<BR>\n", 10));
?>
</BODY>
</HTML>