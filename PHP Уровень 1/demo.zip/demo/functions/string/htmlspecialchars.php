<HTML>
<HEAD>
<TITLE>htmlspecialchars</TITLE>
</HEAD>
<BODY>
<?
	$text = "Use <HTML> to begin a document.";
	print(htmlspecialchars($text));
?>
</BODY>
</HTML>