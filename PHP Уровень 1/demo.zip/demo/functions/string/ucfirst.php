<HTML>
<HEAD>
<TITLE>ucfirst</TITLE>
</HEAD>
<BODY>
<?
	print(ucfirst("i forgot to capitalize something."));
?>
</BODY>
</HTML>