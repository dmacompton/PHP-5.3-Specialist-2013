<HTML>
<HEAD>
<TITLE>substr</TITLE>
</HEAD>
<BODY>
<?
	$text = "My dog's name is Angus.";

	//print Angus
	print(substr($text, 17, 5));
?>
</BODY>
</HTML>