<HTML>
<HEAD>
<TITLE>print</TITLE>
</HEAD>
<BODY>
<?
  print("hello world!<BR>\n");
?>
</BODY>
</HTML>