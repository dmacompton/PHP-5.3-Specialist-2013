<HTML>
<HEAD>
<TITLE>end</TITLE>
</HEAD>
<BODY>
<?
	$colors = array("red", "green", "blue");
	end($colors);
	print(current($colors));
?>
</BODY>
</HTML>