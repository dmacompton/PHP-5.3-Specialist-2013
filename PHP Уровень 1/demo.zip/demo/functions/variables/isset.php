<HTML>
<HEAD>
<TITLE>isset</TITLE>
</HEAD>
<BODY>
<?
	if(isset($Name))
	{
		print("Your Name is $Name");
	}
	else
	{
		print("I don't know your name");
	}
?>
</BODY>
</HTML>