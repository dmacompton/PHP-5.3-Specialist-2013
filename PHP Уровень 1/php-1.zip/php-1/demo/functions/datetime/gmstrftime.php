<HTML>
<HEAD>
<TITLE>gmstrftime</TITLE>
</HEAD>
<BODY>
<?
	print(gmstrftime("%A, %c", mktime(0, 0, 0, 1, 1, 1970)));
?>
</BODY>
</HTML>