<HTML>
<HEAD>
<TITLE>is_array</TITLE>
</HEAD>
<BODY>
<?
	$colors = array("red", "blue", "green");
	if(is_array($colors))
	{
		print("colors is an array");
	}
?>
</BODY>
</HTML>