<HTML>
<HEAD>
<TITLE>is_double</TITLE>
</HEAD>
<BODY>
<?
	$Temperature = 15.23;
	if(is_double($Temperature))
	{
		print("Temperature is a double");
	}
?>
</BODY>
</HTML>