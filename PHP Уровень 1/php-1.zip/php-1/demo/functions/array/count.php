<HTML>
<HEAD>
<TITLE>count</TITLE>
</HEAD>
<BODY>
<?
	$colors = array("red", "green", "blue");
	print(count($colors));
?>
</BODY>
</HTML>