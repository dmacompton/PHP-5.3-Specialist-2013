<HTML>
<HEAD>
<TITLE>ucwords</TITLE>
</HEAD>
<BODY>
<?
	print(ucwords("core PHP programming"));
?>
</BODY>
</HTML>