<HTML>
<HEAD>
<TITLE>convert_cyr_string</TITLE>
</HEAD>
<BODY>
<?
	$new = convert_cyr_string($old, "a", "w");
?>
</BODY>
</HTML>