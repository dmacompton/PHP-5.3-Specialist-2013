<HTML>
<HEAD>
<TITLE>sqrt</TITLE>
</HEAD>
<BODY>
<?
	//prints 9
	print(sqrt(81.0));
?>
</BODY>
</HTML>