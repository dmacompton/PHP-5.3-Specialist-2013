<HTML>
<HEAD>
<TITLE>abs</TITLE>
</HEAD>
<BODY>
<?
	//prints 13
	print(abs(-13));
?>
</BODY>
</HTML>