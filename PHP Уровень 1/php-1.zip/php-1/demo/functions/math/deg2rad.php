<HTML>
<HEAD>
<TITLE>deg2rad</TITLE>
</HEAD>
<BODY>
<?
	//prints 1.5707963267949
	print(deg2rad(90));
?>
</BODY>
</HTML>