<HTML>
<HEAD>
<TITLE>hexdec</TITLE>
</HEAD>
<BODY>
<?
	print(hexdec("FF"));
	print("<BR>\n");
	print(hexdec("0x7FAD"));
	print("<BR>\n");
?>

</BODY>
</HTML>