<HTML>
<HEAD>
<TITLE>pow</TITLE>
</HEAD>
<BODY>
<?
	//print 32
	print(pow(2, 5));
?>
</BODY>
</HTML>