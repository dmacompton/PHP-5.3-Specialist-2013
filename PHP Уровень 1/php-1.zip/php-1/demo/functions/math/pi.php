<HTML>
<HEAD>
<TITLE>pi</TITLE>
</HEAD>
<BODY>
<?
	//prints 3.1415926535898
	print(pi() . "<BR>\n");

	//prints 3.1415926535898
	print(M_PI . "<BR>\n");
?>
</BODY>
</HTML>