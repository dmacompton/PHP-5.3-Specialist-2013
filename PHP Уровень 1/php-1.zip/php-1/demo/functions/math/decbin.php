<HTML>
<HEAD>
<TITLE>decbin</TITLE>
</HEAD>
<BODY>
<?
	//prints 11111111
	print(decbin(255));
?>

</BODY>
</HTML>