﻿<?php
	setcookie("test", "test");
?>