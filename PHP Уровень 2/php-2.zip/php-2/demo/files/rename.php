<HTML>
<HEAD>
<TITLE>rename</TITLE>
</HEAD>
<BODY>
<?
	rename("data.txt", "/upload/newdata.log");
?>
</BODY>
</HTML>