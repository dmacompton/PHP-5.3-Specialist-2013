<?
header("Content-type: text/xml");
?>
<html>
<head>
	<title>My page</title>
	<!--meta http-equiv='Content-Type' content='text/html'/-->
</head>

<body>
<h1>My page</h1>


</body>
</html>
